<!--
File: CHANGELOG.md
Project: WatchLedger JSON
Description: Human-readable release history rendered by changelog.php.
Author: Jason Lamb / ChatGPT
Created: 2026-07-02
Modified: 2026-07-02
Version: 0.1.0
-->

# Changelog

## 0.1.0 - 2026-07-02

- Created initial PHP/JSON mobile-first watch tracker.
- Added JSON storage helpers with file locking and atomic saves.
- Added user authentication with seeded `admin` and `testuser` accounts.
- Added admin-only user management and user library management.
- Blocked admin accounts from personal show/movie tracking.
- Added user registration.
- Added manual media add workflow.
- Added optional TMDB search endpoint and cache folder.
- Added watch status, ratings, notes, and TV episode progress fields.
- Added public sharing toggle per user.
- Added basic user connection request/accept/decline workflow.
- Added `changelog.php` to render this file.
- Added `TASKS.md` to make the project easy to resume later.
- Added `README.md` with setup, credentials, security notes, and import roadmap.
- Added `.placeholder` files where empty folders are expected.
