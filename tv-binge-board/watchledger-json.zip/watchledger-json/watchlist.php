<?php
/**
 * File: watchlist.php
 * Project: WatchLedger JSON
 * Description: Full editable library list for normal users.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';
$user = app_require_login();

app_page_header('My List');
if (!app_can_track($user)):
?>
<section class="card">
    <h1>No personal list for admin</h1>
    <p>Use <a href="admin/users.php">Manage users</a> to view or edit other accounts.</p>
</section>
<?php
else:
$filter = (string)($_GET['status'] ?? '');
$library = app_library($user['username']);
$items = $library['items'];
if ($filter !== '') {
    $items = array_values(array_filter($items, fn($i) => ($i['status'] ?? '') === $filter));
}
usort($items, fn($a, $b) => strcmp(strtolower((string)($a['title'] ?? '')), strtolower((string)($b['title'] ?? ''))));
?>
<section class="card">
    <h1>My List</h1>
    <div class="chip-row">
        <a class="chip" href="watchlist.php">All</a>
        <?php foreach (app_statuses() as $status => $label): ?><a class="chip" href="watchlist.php?status=<?= e($status) ?>"><?= e($label) ?></a><?php endforeach; ?>
    </div>
</section>
<div class="media-list">
    <?php if (!$items): ?><p class="muted">No matching items.</p><?php endif; ?>
    <?php foreach ($items as $item) app_render_media_card($item, true); ?>
</div>
<?php endif; app_page_footer(); ?>
