<?php
/**
 * File: admin/user-library.php
 * Project: WatchLedger JSON
 * Description: Admin-only page for viewing, adding, editing, and deleting another user's tracked media.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
app_require_admin();
$targetUsername = app_sanitize_username((string)($_GET['u'] ?? ''));
$target = $targetUsername !== '' ? app_find_user($targetUsername) : null;
if (!$target || ($target['role'] ?? '') === 'admin') {
    http_response_code(404);
    exit('User not found.');
}
$library = app_library($targetUsername);
$items = $library['items'];
usort($items, fn($a, $b) => strcmp(strtolower((string)($a['title'] ?? '')), strtolower((string)($b['title'] ?? ''))));
app_page_header('Manage User Library');
?>
<section class="card">
    <h1>Manage <?= e((string)($target['display_name'] ?? $targetUsername)) ?>’s list</h1>
    <p class="muted">@<?= e($targetUsername) ?></p>
    <a class="button secondary" href="../public.php?u=<?= e($targetUsername) ?>">View shared page</a>
</section>
<section class="card">
    <h2>Add manual item</h2>
    <form method="post" action="../api/add-media.php" class="stack">
        <input type="hidden" name="csrf_token" value="<?= e(app_csrf_token()) ?>">
        <input type="hidden" name="target_user" value="<?= e($targetUsername) ?>">
        <input type="hidden" name="redirect" value="../admin/user-library.php?u=<?= e($targetUsername) ?>">
        <label>Type <select name="type"><option value="tv">TV show</option><option value="movie">Movie</option></select></label>
        <label>Title <input name="title" required></label>
        <label>Year <input name="year" inputmode="numeric" pattern="[0-9]{4}"></label>
        <label>Status <select name="status"><?php foreach (app_statuses() as $status => $label): ?><option value="<?= e($status) ?>"><?= e($label) ?></option><?php endforeach; ?></select></label>
        <button type="submit">Add to user list</button>
    </form>
</section>
<div class="media-list">
    <?php if (!$items): ?><p class="muted">No items yet.</p><?php endif; ?>
    <?php foreach ($items as $item) app_render_media_card($item, true, $targetUsername); ?>
</div>
<?php app_page_footer(); ?>
