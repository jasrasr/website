<?php
/**
 * File: admin/users.php
 * Project: WatchLedger JSON
 * Description: Admin-only user list and account management entry point.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
$user = app_require_admin();
$accounts = app_get_accounts()['users'];
app_page_header('Manage Users');
?>
<section class="card">
    <h1>Manage users</h1>
    <p>The admin account can inspect and edit normal user libraries, but it does not track its own shows.</p>
</section>
<section class="card">
    <div class="user-list">
    <?php foreach ($accounts as $account): ?>
        <article class="user-card">
            <div>
                <strong><?= e((string)($account['display_name'] ?? $account['username'])) ?></strong>
                <p class="muted">@<?= e((string)$account['username']) ?> · <?= e((string)$account['role']) ?> <?= !empty($account['public_share_enabled']) ? '· public' : '' ?></p>
            </div>
            <?php if (($account['role'] ?? '') !== 'admin'): ?>
                <a class="button secondary" href="user-library.php?u=<?= e((string)$account['username']) ?>">Manage list</a>
            <?php else: ?>
                <span class="pill admin">Admin</span>
            <?php endif; ?>
        </article>
    <?php endforeach; ?>
    </div>
</section>
<?php app_page_footer(); ?>
