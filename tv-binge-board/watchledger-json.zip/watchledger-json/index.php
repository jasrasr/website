<?php
/**
 * File: index.php
 * Project: WatchLedger JSON
 * Description: Entry point that routes authenticated users to the dashboard and guests to login.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';

header('Location: ' . (app_current_user() ? 'dashboard.php' : 'login.php'));
exit;
