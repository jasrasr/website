<?php
/**
 * File: public.php
 * Project: WatchLedger JSON
 * Description: Public or connection-authorized list view for a selected user.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';
$viewer = app_current_user();
$targetUsername = app_sanitize_username((string)($_GET['u'] ?? ''));
$target = $targetUsername !== '' ? app_find_user($targetUsername) : null;

if (!$target || ($target['role'] ?? '') === 'admin') {
    http_response_code(404);
    app_page_header('List not found');
    echo '<section class="card"><h1>List not found</h1></section>';
    app_page_footer();
    exit;
}

$profile = app_profile($targetUsername);
$public = !empty($profile['public_share_enabled']);
$allowed = $public || ($viewer && app_can_view_library($viewer, $targetUsername));

app_page_header('Shared List');
if (!$allowed): ?>
<section class="card">
    <h1>This list is private</h1>
    <p>Sign in and connect with this user, or ask them to enable public sharing.</p>
</section>
<?php else:
$library = app_library($targetUsername);
$items = $library['items'];
usort($items, fn($a, $b) => strcmp(strtolower((string)($a['title'] ?? '')), strtolower((string)($b['title'] ?? ''))));
?>
<section class="card">
    <h1><?= e((string)($profile['display_name'] ?? $target['display_name'] ?? $targetUsername)) ?>’s List</h1>
    <?php if (!empty($profile['bio'])): ?><p><?= e((string)$profile['bio']) ?></p><?php endif; ?>
    <p class="muted"><?= $public ? 'Public list' : 'Shared through connection' ?></p>
</section>
<div class="media-list">
    <?php if (!$items): ?><p class="muted">No tracked items yet.</p><?php endif; ?>
    <?php foreach ($items as $item) app_render_media_card($item, false); ?>
</div>
<?php endif; app_page_footer(); ?>
