<?php
/**
 * File: settings.php
 * Project: WatchLedger JSON
 * Description: User profile, sharing preferences, and account actions.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/functions.php';
$user = app_require_login();
$profile = app_profile($user['username']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    app_verify_csrf();
    $profile['display_name'] = trim((string)($_POST['display_name'] ?? $profile['display_name'] ?? $user['username']));
    $profile['bio'] = trim((string)($_POST['bio'] ?? ''));
    $profile['public_share_enabled'] = isset($_POST['public_share_enabled']);
    app_save_profile($user['username'], $profile);

    $user['display_name'] = $profile['display_name'];
    $user['public_share_enabled'] = $profile['public_share_enabled'];
    app_update_account($user);

    app_flash('Settings saved.', 'success');
    header('Location: settings.php');
    exit;
}

app_page_header('Settings');
?>
<section class="card">
    <h1>Settings</h1>
    <form method="post" class="stack">
        <input type="hidden" name="csrf_token" value="<?= e(app_csrf_token()) ?>">
        <label>Display name
            <input name="display_name" value="<?= e((string)($profile['display_name'] ?? $user['display_name'] ?? $user['username'])) ?>">
        </label>
        <label>Bio
            <textarea name="bio" rows="3"><?= e((string)($profile['bio'] ?? '')) ?></textarea>
        </label>
        <?php if (app_can_track($user)): ?>
        <label class="checkbox-row">
            <input type="checkbox" name="public_share_enabled" value="1" <?= !empty($profile['public_share_enabled']) ? 'checked' : '' ?>>
            Share my list publicly
        </label>
        <p class="muted">Public URL: <a href="public.php?u=<?= e($user['username']) ?>">public.php?u=<?= e($user['username']) ?></a></p>
        <?php else: ?>
        <p class="muted">Admin accounts do not have public tracking lists.</p>
        <?php endif; ?>
        <button type="submit">Save settings</button>
    </form>
</section>
<section class="card">
    <h2>Account</h2>
    <p><a class="button secondary" href="logout.php">Sign out</a></p>
</section>
<?php app_page_footer(); ?>
