<!--
File: TASKS.md
Project: WatchLedger JSON
Description: Restart-friendly task list and implementation plan for continuing development on another device.
Author: Jason Lamb / ChatGPT
Created: 2026-07-02
Modified: 2026-07-02
Version: 0.1.0
-->

# WatchLedger Task List

## Current state

- [x] PHP/JSON project scaffold created.
- [x] Mobile-first layout created.
- [x] Login/logout added.
- [x] User registration added.
- [x] Seeded `admin` account added.
- [x] Seeded `testuser` account added.
- [x] Admin does not track its own shows/movies.
- [x] Admin can manage normal user libraries.
- [x] User library JSON structure created.
- [x] Public sharing toggle added.
- [x] Connections scaffolding added.
- [x] Manual add added.
- [x] TMDB search endpoint added.
- [x] Changelog viewer added.
- [x] README added.
- [x] `.placeholder` files added.

## Next development pass

- [ ] Add password change page.
- [ ] Add admin reset-password action.
- [ ] Add admin disable/enable user action.
- [ ] Add option to disable public registration.
- [ ] Add CSV export for each user's library.
- [ ] Add JSON export for each user's library.
- [ ] Add CSV import review screen.
- [ ] Add duplicate detection during import.
- [ ] Add poster refresh action using TMDB ID.
- [ ] Add per-season episode grid for TV shows.
- [ ] Add completed percentage for TV shows.
- [ ] Add search/filter/sort on `watchlist.php`.
- [ ] Add user profile avatars.
- [ ] Add PWA icons.
- [ ] Add backup script for the `data/` folder.

## Future import plan

- [ ] Create `imports.php` page.
- [ ] Accept `.csv` and `.json` uploads into `data/users/{username}/imports/`.
- [ ] Parse imports into a temporary review JSON file.
- [ ] Show parsed rows in a review UI.
- [ ] Let the user map columns: title, type, status, rating, season, episode, notes.
- [ ] Require final confirmation before importing.
- [ ] Write import log with timestamp and source filename.

## Future screenshot-assisted import plan

- [ ] Create `upload-screenshot.php` page.
- [ ] Store screenshots in `data/users/{username}/uploads/`.
- [ ] Add image validation: extension, MIME type, file size, dimensions.
- [ ] Create review queue JSON file.
- [ ] Add OCR/AI processing outside the core save path.
- [ ] Display parsed guesses with confidence levels.
- [ ] Require manual approval before adding items to the library.
- [ ] Keep original screenshot attached to import history for audit/debugging.

## Security hardening

- [ ] Change seed passwords.
- [ ] Add login rate limiting.
- [ ] Add password reset flow.
- [ ] Add stronger session cookie settings for HTTPS.
- [ ] Add server-side upload scanning before screenshot import.
- [ ] Add recurring JSON backup/export.
- [ ] Add activity log for admin changes.

## Pause/resume checklist

When resuming on another device:

1. Read `README.md`.
2. Open `CHANGELOG.md` or `changelog.php`.
3. Review this file.
4. Confirm whether `includes/config.local.php` exists on the target server.
5. Confirm that `data/.htaccess` is uploaded.
6. Sign in as `admin` and confirm user management works.
7. Sign in as `testuser` and confirm manual add works.
8. Add TMDB key only after the core app loads correctly.
