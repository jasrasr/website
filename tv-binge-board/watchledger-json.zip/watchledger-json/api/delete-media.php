<?php
/**
 * File: api/delete-media.php
 * Project: WatchLedger JSON
 * Description: Deletes a movie or show from the current user's library, or a target user's library for admins.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
$user = app_require_login();
app_verify_csrf();

$targetUser = app_is_admin($user) ? app_sanitize_username((string)($_POST['target_user'] ?? '')) : (string)$user['username'];
if ($targetUser === '' || !app_find_user($targetUser)) {
    http_response_code(400);
    exit('Invalid target user.');
}

$uid = (string)($_POST['uid'] ?? '');
$library = app_library($targetUser);
$library['items'] = array_values(array_filter($library['items'], fn($item) => ($item['uid'] ?? '') !== $uid));
app_save_library($targetUser, $library);
app_flash('Item deleted.', 'success');

$redirect = (string)($_POST['redirect'] ?? '../watchlist.php');
header('Location: ' . $redirect);
exit;
