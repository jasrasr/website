<?php
/**
 * File: api/add-media.php
 * Project: WatchLedger JSON
 * Description: Adds a movie or TV show to the current user's library, or a target user's library for admins.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/../includes/functions.php';
$user = app_require_login();
app_verify_csrf();

$targetUser = app_is_admin($user) ? app_sanitize_username((string)($_POST['target_user'] ?? '')) : (string)$user['username'];
if ($targetUser === '' || !app_find_user($targetUser)) {
    http_response_code(400);
    exit('Invalid target user.');
}
if (!app_is_admin($user) && !app_can_track($user)) {
    http_response_code(403);
    exit('This account cannot track media.');
}

$type = (string)($_POST['type'] ?? 'movie');
$type = in_array($type, ['movie', 'tv'], true) ? $type : 'movie';
$title = trim((string)($_POST['title'] ?? ''));
if ($title === '') {
    http_response_code(400);
    exit('Title is required.');
}
$tmdbId = isset($_POST['tmdb_id']) && $_POST['tmdb_id'] !== '' ? (int)$_POST['tmdb_id'] : null;
$uid = app_make_media_uid($type, $tmdbId, $title);
$library = app_library($targetUser);
$index = app_find_media_index($library, $uid);
$item = [
    'uid' => $uid,
    'source' => $tmdbId ? 'tmdb' : 'manual',
    'tmdb_id' => $tmdbId,
    'type' => $type,
    'title' => $title,
    'year' => trim((string)($_POST['year'] ?? '')),
    'poster_path' => trim((string)($_POST['poster_path'] ?? '')),
    'poster_url' => trim((string)($_POST['poster_url'] ?? '')),
    'overview' => trim((string)($_POST['overview'] ?? '')),
    'status' => (string)($_POST['status'] ?? 'watchlist'),
    'rating' => null,
    'notes' => '',
    'episodes' => [],
    'created_at' => date(DATE_ATOM),
    'updated_at' => date(DATE_ATOM),
];

if ($index === null) {
    $library['items'][] = $item;
    app_flash('Added to list.', 'success');
} else {
    $library['items'][$index] = array_merge($library['items'][$index], array_filter($item, fn($v) => $v !== null && $v !== ''));
    $library['items'][$index]['updated_at'] = date(DATE_ATOM);
    app_flash('Existing item updated.', 'success');
}
app_save_library($targetUser, $library);

$redirect = (string)($_POST['redirect'] ?? '../watchlist.php');
header('Location: ' . $redirect);
exit;
