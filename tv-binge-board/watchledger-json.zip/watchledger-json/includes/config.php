<?php
/**
 * File: includes/config.php
 * Project: WatchLedger JSON
 * Description: Application configuration, version constants, timezone, and optional local overrides.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

const APP_NAME = 'WatchLedger';
const APP_VERSION = '0.1.0';
const APP_TIMEZONE = 'America/New_York';
const APP_SESSION_NAME = 'watchledger_session';
const APP_DEFAULT_POSTER = 'assets/img/poster-placeholder.svg';
const APP_PUBLIC_SITE_NOTE = 'This site tracks watch history. It does not stream TV shows or movies.';

date_default_timezone_set(APP_TIMEZONE);

define('APP_ROOT', dirname(__DIR__));
define('APP_DATA_DIR', APP_ROOT . DIRECTORY_SEPARATOR . 'data');
define('APP_CACHE_DIR', APP_DATA_DIR . DIRECTORY_SEPARATOR . 'cache');
define('APP_UPLOADS_DIR', APP_DATA_DIR . DIRECTORY_SEPARATOR . 'uploads');

// Do not commit real secrets. Create includes/config.local.php and define TMDB_API_KEY there.
const TMDB_API_KEY = '';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/w342';

$localConfig = __DIR__ . DIRECTORY_SEPARATOR . 'config.local.php';
if (is_file($localConfig)) {
    require_once $localConfig;
}
