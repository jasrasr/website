<?php
/**
 * File: includes/config.local.example.php
 * Project: WatchLedger JSON
 * Description: Example local-only configuration file for secrets such as the TMDB API key.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

// Copy this file to includes/config.local.php and add your real API key.
define('TMDB_API_KEY_LOCAL', 'paste-your-tmdb-api-key-here');

if (!defined('TMDB_API_KEY') || TMDB_API_KEY === '') {
    // This constant cannot be redefined if config.php already declared it as a const.
    // The app reads TMDB_API_KEY_LOCAL first when present.
}
