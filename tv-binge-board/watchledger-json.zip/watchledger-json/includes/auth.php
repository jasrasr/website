<?php
/**
 * File: includes/auth.php
 * Project: WatchLedger JSON
 * Description: Session, authentication, authorization, account, and CSRF helpers.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/json-store.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name(APP_SESSION_NAME);
    session_start();
}

function app_accounts_path(): string
{
    return APP_DATA_DIR . DIRECTORY_SEPARATOR . 'accounts.json';
}

function app_default_accounts(): array
{
    return [
        '_meta' => app_json_meta('Application user accounts and password hashes.'),
        'users' => [],
    ];
}

function app_get_accounts(): array
{
    $accounts = app_load_json(app_accounts_path(), app_default_accounts());
    if (!isset($accounts['users']) || !is_array($accounts['users'])) {
        $accounts['users'] = [];
    }
    return $accounts;
}

function app_save_accounts(array $accounts): void
{
    $accounts['_meta']['updated_at'] = date(DATE_ATOM);
    app_save_json(app_accounts_path(), $accounts);
}

function app_sanitize_username(string $username): string
{
    $username = strtolower(trim($username));
    return preg_replace('/[^a-z0-9._-]/', '', $username) ?? '';
}

function app_find_user(string $username): ?array
{
    $username = app_sanitize_username($username);
    foreach (app_get_accounts()['users'] as $user) {
        if (($user['username'] ?? '') === $username) {
            return $user;
        }
    }
    return null;
}

function app_update_account(array $updatedUser): void
{
    $accounts = app_get_accounts();
    foreach ($accounts['users'] as $index => $user) {
        if (($user['username'] ?? '') === ($updatedUser['username'] ?? '')) {
            $accounts['users'][$index] = $updatedUser;
            app_save_accounts($accounts);
            return;
        }
    }
    throw new RuntimeException('Account not found: ' . ($updatedUser['username'] ?? 'unknown'));
}

function app_create_user(string $username, string $password, string $displayName = ''): array
{
    $username = app_sanitize_username($username);
    if ($username === '' || strlen($username) < 3) {
        throw new InvalidArgumentException('Username must be at least 3 valid characters.');
    }
    if (strlen($password) < 8) {
        throw new InvalidArgumentException('Password must be at least 8 characters.');
    }
    if (app_find_user($username) !== null) {
        throw new InvalidArgumentException('Username already exists.');
    }

    $accounts = app_get_accounts();
    $user = [
        'id' => bin2hex(random_bytes(8)),
        'username' => $username,
        'display_name' => trim($displayName) !== '' ? trim($displayName) : $username,
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'role' => 'user',
        'can_track' => true,
        'public_share_enabled' => false,
        'created_at' => date(DATE_ATOM),
        'last_login_at' => null,
    ];
    $accounts['users'][] = $user;
    app_save_accounts($accounts);
    app_seed_user_files($username, $user['display_name']);
    return $user;
}

function app_login(string $username, string $password): bool
{
    $user = app_find_user($username);
    if ($user === null || !password_verify($password, $user['password_hash'] ?? '')) {
        return false;
    }

    session_regenerate_id(true);
    $_SESSION['user'] = $user['username'];

    $user['last_login_at'] = date(DATE_ATOM);
    app_update_account($user);
    app_seed_user_files($user['username'], $user['display_name'] ?? $user['username']);
    return true;
}

function app_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], (bool)$params['secure'], (bool)$params['httponly']);
    }
    session_destroy();
}

function app_current_user(): ?array
{
    if (empty($_SESSION['user'])) {
        return null;
    }
    return app_find_user((string)$_SESSION['user']);
}

function app_base_prefix(): string
{
    $script = str_replace('\\', '/', (string)($_SERVER['SCRIPT_NAME'] ?? ''));
    return preg_match('#/(admin|api)/#', $script) ? '../' : '';
}

function app_require_login(): array
{
    $user = app_current_user();
    if ($user === null) {
        header('Location: ' . app_base_prefix() . 'login.php');
        exit;
    }
    return $user;
}

function app_require_admin(): array
{
    $user = app_require_login();
    if (($user['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Forbidden');
    }
    return $user;
}

function app_is_admin(?array $user = null): bool
{
    $user = $user ?? app_current_user();
    return ($user['role'] ?? '') === 'admin';
}

function app_can_track(?array $user = null): bool
{
    $user = $user ?? app_current_user();
    return (bool)($user['can_track'] ?? false) && !app_is_admin($user);
}

function app_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return (string)$_SESSION['csrf_token'];
}

function app_verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!is_string($token) || !hash_equals(app_csrf_token(), $token)) {
        http_response_code(400);
        exit('Invalid CSRF token.');
    }
}

function app_user_dir(string $username): string
{
    return APP_DATA_DIR . DIRECTORY_SEPARATOR . 'users' . DIRECTORY_SEPARATOR . app_sanitize_username($username);
}

function app_user_file(string $username, string $filename): string
{
    return app_user_dir($username) . DIRECTORY_SEPARATOR . $filename;
}

function app_seed_user_files(string $username, string $displayName = ''): void
{
    $username = app_sanitize_username($username);
    app_ensure_dir(app_user_dir($username));
    app_ensure_dir(app_user_dir($username) . DIRECTORY_SEPARATOR . 'imports');
    app_ensure_dir(app_user_dir($username) . DIRECTORY_SEPARATOR . 'uploads');

    $profile = app_user_file($username, 'profile.json');
    if (!is_file($profile)) {
        app_save_json($profile, [
            '_meta' => app_json_meta('User profile, sharing, and privacy preferences.'),
            'username' => $username,
            'display_name' => $displayName !== '' ? $displayName : $username,
            'bio' => '',
            'public_share_enabled' => false,
            'created_at' => date(DATE_ATOM),
        ]);
    }

    $library = app_user_file($username, 'library.json');
    if (!is_file($library)) {
        app_save_json($library, [
            '_meta' => app_json_meta('Tracked shows, movies, statuses, ratings, notes, and episode progress.'),
            'items' => [],
        ]);
    }

    $connections = app_user_file($username, 'connections.json');
    if (!is_file($connections)) {
        app_save_json($connections, [
            '_meta' => app_json_meta('User-to-user sharing connections and pending requests.'),
            'connections' => [],
            'incoming_requests' => [],
            'outgoing_requests' => [],
        ]);
    }
}
