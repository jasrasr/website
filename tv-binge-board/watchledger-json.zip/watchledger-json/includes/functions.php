<?php
/**
 * File: includes/functions.php
 * Project: WatchLedger JSON
 * Description: Shared UI, library, profile, and connection helper functions.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/auth.php';

function e(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function app_url(string $path): string
{
    return e($path);
}

function app_href(string $path): string
{
    return app_base_prefix() . ltrim($path, '/');
}

function app_flash(?string $message = null, string $type = 'info'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['message' => $message, 'type' => $type];
        return null;
    }
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}

function app_page_header(string $title): void
{
    $user = app_current_user();
    $flash = app_flash();
    ?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#111827">
    <title><?= e($title) ?> - <?= e(APP_NAME) ?></title>
    <link rel="stylesheet" href="<?= e(app_href('assets/css/app.css')) ?>">
    <link rel="manifest" href="<?= e(app_href('manifest.webmanifest')) ?>">
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?= e(app_href('dashboard.php')) ?>"><?= e(APP_NAME) ?></a>
    <span class="version">v<?= e(APP_VERSION) ?></span>
</header>
<main class="container">
<?php if ($flash): ?>
    <div class="alert <?= e($flash['type'] ?? 'info') ?>"><?= e($flash['message'] ?? '') ?></div>
<?php endif; ?>
<?php if ($user): ?>
    <section class="user-strip">
        <span>Signed in as <strong><?= e($user['display_name'] ?? $user['username']) ?></strong></span>
        <?php if (app_is_admin($user)): ?><span class="pill admin">Admin</span><?php endif; ?>
    </section>
<?php endif; ?>
<?php
}

function app_page_footer(): void
{
    $user = app_current_user();
    ?>
</main>
<?php if ($user): ?>
<nav class="bottom-nav" aria-label="Main navigation">
    <a href="<?= e(app_href('dashboard.php')) ?>">Home</a>
    <?php if (app_can_track($user)): ?>
        <a href="<?= e(app_href('search.php')) ?>">Search</a>
        <a href="<?= e(app_href('watchlist.php')) ?>">List</a>
        <a href="<?= e(app_href('connections.php')) ?>">People</a>
    <?php else: ?>
        <a href="<?= e(app_href('admin/users.php')) ?>">Users</a>
    <?php endif; ?>
    <a href="<?= e(app_href('settings.php')) ?>">Settings</a>
</nav>
<?php endif; ?>
<footer class="footer">
    <p><?= e(APP_PUBLIC_SITE_NOTE) ?></p>
    <p>Metadata may use TMDB. This product uses the TMDB API but is not endorsed or certified by TMDB.</p>
    <p><a href="<?= e(app_href('changelog.php')) ?>">Changelog</a> · <a href="<?= e(app_href('README.md')) ?>">README</a> · <a href="<?= e(app_href('TASKS.md')) ?>">Task list</a></p>
</footer>
<script src="<?= e(app_href('assets/js/app.js')) ?>"></script>
</body>
</html><?php
}

function app_library(string $username): array
{
    app_seed_user_files($username);
    $library = app_load_json(app_user_file($username, 'library.json'), [
        '_meta' => app_json_meta('Tracked shows and movies.'),
        'items' => [],
    ]);
    if (!isset($library['items']) || !is_array($library['items'])) {
        $library['items'] = [];
    }
    return $library;
}

function app_save_library(string $username, array $library): void
{
    $library['_meta']['updated_at'] = date(DATE_ATOM);
    app_save_json(app_user_file($username, 'library.json'), $library);
}

function app_make_media_uid(string $type, ?int $tmdbId, string $title): string
{
    $type = in_array($type, ['movie', 'tv'], true) ? $type : 'movie';
    if ($tmdbId !== null && $tmdbId > 0) {
        return $type . '-' . $tmdbId;
    }
    return 'manual-' . substr(sha1($type . '|' . strtolower(trim($title))), 0, 16);
}

function app_find_media_index(array $library, string $uid): ?int
{
    foreach ($library['items'] as $index => $item) {
        if (($item['uid'] ?? '') === $uid) {
            return $index;
        }
    }
    return null;
}

function app_statuses(): array
{
    return [
        'watchlist' => 'Want to Watch',
        'watching' => 'Watching',
        'watched' => 'Watched',
        'completed' => 'Completed',
        'dropped' => 'Dropped',
    ];
}

function app_excerpt(string $value, int $width = 180): string
{
    if (function_exists('mb_strimwidth')) {
        return mb_strimwidth($value, 0, $width, '…');
    }
    return strlen($value) > $width ? substr($value, 0, $width - 3) . '...' : $value;
}

function app_render_media_card(array $item, bool $editable = false, string $targetUser = ''): void
{
    $poster = (string)($item['poster_url'] ?? '');
    if ($poster === '' && !empty($item['poster_path'])) {
        $poster = TMDB_IMAGE_BASE . $item['poster_path'];
    }
    if ($poster === '') {
        $poster = app_href(APP_DEFAULT_POSTER);
    }
    $uid = (string)($item['uid'] ?? '');
    ?>
    <article class="media-card">
        <img class="poster" src="<?= e($poster) ?>" alt="Poster for <?= e($item['title'] ?? 'media') ?>" loading="lazy">
        <div class="media-body">
            <div class="media-title-row">
                <h3><?= e($item['title'] ?? 'Untitled') ?></h3>
                <span class="pill"><?= e(strtoupper((string)($item['type'] ?? 'movie'))) ?></span>
            </div>
            <p class="muted"><?= e((string)($item['year'] ?? '')) ?> · <?= e(app_statuses()[$item['status'] ?? 'watchlist'] ?? ($item['status'] ?? 'watchlist')) ?></p>
            <?php if (!empty($item['overview'])): ?><p><?= e(app_excerpt((string)$item['overview'], 180)) ?></p><?php endif; ?>
            <?php if (!empty($item['rating'])): ?><p class="rating">Rating: <?= e((string)$item['rating']) ?>/10</p><?php endif; ?>
            <?php if (!empty($item['notes'])): ?><p class="notes"><?= e((string)$item['notes']) ?></p><?php endif; ?>
            <?php if (($item['type'] ?? '') === 'tv' && !empty($item['last_episode'])): ?>
                <p class="muted">Last episode: S<?= e((string)($item['last_episode']['season'] ?? '?')) ?>E<?= e((string)($item['last_episode']['episode'] ?? '?')) ?></p>
            <?php endif; ?>
            <?php if ($editable): ?>
                <details class="edit-panel">
                    <summary>Edit</summary>
                    <form method="post" action="<?= e(app_href('api/update-status.php')) ?>" class="stack">
                        <input type="hidden" name="csrf_token" value="<?= e(app_csrf_token()) ?>">
                        <input type="hidden" name="uid" value="<?= e($uid) ?>">
                        <?php if ($targetUser !== ''): ?><input type="hidden" name="target_user" value="<?= e($targetUser) ?>"><?php endif; ?>
                        <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '../watchlist.php') ?>">
                        <label>Status
                            <select name="status">
                                <?php foreach (app_statuses() as $status => $label): ?>
                                    <option value="<?= e($status) ?>" <?= ($item['status'] ?? '') === $status ? 'selected' : '' ?>><?= e($label) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </label>
                        <label>Rating
                            <input type="number" name="rating" min="1" max="10" value="<?= e((string)($item['rating'] ?? '')) ?>" placeholder="1-10">
                        </label>
                        <label>Notes
                            <textarea name="notes" rows="3"><?= e((string)($item['notes'] ?? '')) ?></textarea>
                        </label>
                        <?php if (($item['type'] ?? '') === 'tv'): ?>
                            <div class="grid-2">
                                <label>Season <input type="number" name="season" min="0" value="<?= e((string)($item['last_episode']['season'] ?? '')) ?>"></label>
                                <label>Episode <input type="number" name="episode" min="0" value="<?= e((string)($item['last_episode']['episode'] ?? '')) ?>"></label>
                            </div>
                        <?php endif; ?>
                        <button type="submit">Save</button>
                    </form>
                    <form method="post" action="<?= e(app_href('api/delete-media.php')) ?>" onsubmit="return confirm('Delete this item from the list?');">
                        <input type="hidden" name="csrf_token" value="<?= e(app_csrf_token()) ?>">
                        <input type="hidden" name="uid" value="<?= e($uid) ?>">
                        <?php if ($targetUser !== ''): ?><input type="hidden" name="target_user" value="<?= e($targetUser) ?>"><?php endif; ?>
                        <input type="hidden" name="redirect" value="<?= e($_SERVER['REQUEST_URI'] ?? '../watchlist.php') ?>">
                        <button class="danger" type="submit">Delete</button>
                    </form>
                </details>
            <?php endif; ?>
        </div>
    </article>
    <?php
}

function app_profile(string $username): array
{
    app_seed_user_files($username);
    return app_load_json(app_user_file($username, 'profile.json'), []);
}

function app_save_profile(string $username, array $profile): void
{
    $profile['_meta']['updated_at'] = date(DATE_ATOM);
    app_save_json(app_user_file($username, 'profile.json'), $profile);
}

function app_connections(string $username): array
{
    app_seed_user_files($username);
    $data = app_load_json(app_user_file($username, 'connections.json'), []);
    foreach (['connections', 'incoming_requests', 'outgoing_requests'] as $key) {
        if (!isset($data[$key]) || !is_array($data[$key])) {
            $data[$key] = [];
        }
    }
    return $data;
}

function app_save_connections(string $username, array $data): void
{
    $data['_meta']['updated_at'] = date(DATE_ATOM);
    app_save_json(app_user_file($username, 'connections.json'), $data);
}

function app_can_view_library(array $viewer, string $targetUsername): bool
{
    if (($viewer['username'] ?? '') === $targetUsername || app_is_admin($viewer)) {
        return true;
    }

    $target = app_find_user($targetUsername);
    if (!$target) {
        return false;
    }

    $targetProfile = app_profile($targetUsername);
    if (!empty($targetProfile['public_share_enabled'])) {
        return true;
    }

    $viewerConnections = app_connections((string)$viewer['username']);
    return in_array($targetUsername, $viewerConnections['connections'], true);
}

function app_simple_markdown(string $markdown): string
{
    $lines = preg_split('/\R/', $markdown) ?: [];
    $html = '';
    $inList = false;
    foreach ($lines as $line) {
        $escaped = e($line);
        if (preg_match('/^###\s+(.*)$/', $line, $m)) {
            if ($inList) { $html .= '</ul>'; $inList = false; }
            $html .= '<h3>' . e($m[1]) . '</h3>';
        } elseif (preg_match('/^##\s+(.*)$/', $line, $m)) {
            if ($inList) { $html .= '</ul>'; $inList = false; }
            $html .= '<h2>' . e($m[1]) . '</h2>';
        } elseif (preg_match('/^#\s+(.*)$/', $line, $m)) {
            if ($inList) { $html .= '</ul>'; $inList = false; }
            $html .= '<h1>' . e($m[1]) . '</h1>';
        } elseif (preg_match('/^- \[([ xX])\]\s+(.*)$/', $line, $m)) {
            if (!$inList) { $html .= '<ul class="task-list">'; $inList = true; }
            $checked = strtolower($m[1]) === 'x' ? ' checked' : '';
            $html .= '<li><input type="checkbox" disabled' . $checked . '> ' . e($m[2]) . '</li>';
        } elseif (preg_match('/^-\s+(.*)$/', $line, $m)) {
            if (!$inList) { $html .= '<ul>'; $inList = true; }
            $html .= '<li>' . e($m[1]) . '</li>';
        } elseif (trim($line) === '') {
            if ($inList) { $html .= '</ul>'; $inList = false; }
        } else {
            if ($inList) { $html .= '</ul>'; $inList = false; }
            $html .= '<p>' . $escaped . '</p>';
        }
    }
    if ($inList) { $html .= '</ul>'; }
    return $html;
}
