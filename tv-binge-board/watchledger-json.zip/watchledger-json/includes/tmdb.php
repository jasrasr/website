<?php
/**
 * File: includes/tmdb.php
 * Project: WatchLedger JSON
 * Description: TMDB API wrapper with basic caching and normalized search results.
 * Author: Jason Lamb / ChatGPT
 * Created: 2026-07-02
 * Modified: 2026-07-02
 * Version: 0.1.0
 */
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

function app_tmdb_key(): string
{
    if (defined('TMDB_API_KEY_LOCAL') && TMDB_API_KEY_LOCAL !== '') {
        return TMDB_API_KEY_LOCAL;
    }
    if (defined('TMDB_API_KEY') && TMDB_API_KEY !== '') {
        return TMDB_API_KEY;
    }
    $env = getenv('TMDB_API_KEY');
    return is_string($env) ? $env : '';
}

function app_tmdb_search(string $query): array
{
    $key = app_tmdb_key();
    if ($key === '') {
        throw new RuntimeException('TMDB API key is not configured. Use manual add or create includes/config.local.php.');
    }

    $query = trim($query);
    if ($query === '') {
        return [];
    }

    app_ensure_dir(APP_CACHE_DIR . DIRECTORY_SEPARATOR . 'tmdb');
    $cachePath = APP_CACHE_DIR . DIRECTORY_SEPARATOR . 'tmdb' . DIRECTORY_SEPARATOR . 'search-' . sha1(strtolower($query)) . '.json';
    $cached = app_load_json($cachePath, []);
    if (!empty($cached['cached_at']) && (time() - strtotime((string)$cached['cached_at']) < 86400) && isset($cached['results'])) {
        return $cached['results'];
    }

    $url = 'https://api.themoviedb.org/3/search/multi?api_key=' . rawurlencode($key) . '&query=' . rawurlencode($query) . '&include_adult=false&language=en-US&page=1';
    $context = stream_context_create([
        'http' => [
            'timeout' => 12,
            'header' => "Accept: application/json\r\nUser-Agent: WatchLedger/" . APP_VERSION . "\r\n",
        ],
    ]);
    $body = @file_get_contents($url, false, $context);
    if ($body === false) {
        throw new RuntimeException('Unable to contact TMDB.');
    }

    $decoded = json_decode($body, true);
    if (!is_array($decoded)) {
        throw new RuntimeException('Invalid TMDB response.');
    }

    $results = [];
    foreach (($decoded['results'] ?? []) as $item) {
        $type = $item['media_type'] ?? '';
        if (!in_array($type, ['movie', 'tv'], true)) {
            continue;
        }
        $title = $type === 'movie' ? ($item['title'] ?? '') : ($item['name'] ?? '');
        $date = $type === 'movie' ? ($item['release_date'] ?? '') : ($item['first_air_date'] ?? '');
        $year = $date !== '' ? substr((string)$date, 0, 4) : '';
        $results[] = [
            'tmdb_id' => (int)($item['id'] ?? 0),
            'type' => $type,
            'title' => $title,
            'year' => $year,
            'poster_path' => $item['poster_path'] ?? '',
            'overview' => $item['overview'] ?? '',
        ];
    }

    app_save_json($cachePath, [
        '_meta' => app_json_meta('TMDB cached search result.'),
        'query' => $query,
        'cached_at' => date(DATE_ATOM),
        'results' => $results,
    ]);

    return $results;
}
